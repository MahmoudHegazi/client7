import scrapy

non_food_urls = []
next_page = response.xpath("//a[@class='pagination--button']/@href").get()
if next_page:
	abs_url = "https://eshop.tesco.com.my"+next_page
yield scrapy.Request(
	url=abs_url,
	callback=self.parse
)


import scrapy

class GroceriesSpider(scrapy.Spider):
	name = 'groceries'
	# create request object initially
	def start_requests(self):
        yield scrapy.Request(url ='https://eshop.tesco.com.my/groceries/en-GB/shop/pets/dog-food/all',callback = self.parse)
        # parse products
	def parse(self, response):
		products = response.xpath("//li[@class ='product-list--list-item first']")
		for product in products:
			yield {
				'name': product.xpath(".//span[@class ='a-size-medium a-color-base a-text-normal']/text()").get(),
				#'price': product.xpath(".//span[@class ='a-price-whole']/text()").get()
                #product-image-wrapper
                'url':  product.xpath('//a[contains(@data-auto, "product-tile--title")]/@href').getall()
                #//img[@class='product-image']/@src
			}
		print()
		print("Next page")
		print()

		#next_page = response.xpath("//a[@class='pagination--button']/@href").get()
		#if next_page:
		#	abs_url = "https://eshop.tesco.com.my".format(next_page)
		#	yield scrapy.Request(
		#		url = abs_url,
		#		callback = self.parse
		#	)
		#else:
		#	print()
		#	print('No Page Left')
		#	print()
