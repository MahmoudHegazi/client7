import requests
from bs4 import BeautifulSoup

#url_part1 = 'https://eshop.tesco.com.my/groceries/en-GB/shop/fresh-food/bakery/all'
#url_part2 = 'headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"}'
#response = requests.get(url_part1,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})

def get_pagination(url):
    #url = 'https://eshop.tesco.com.my/groceries/en-GB/shop/fresh-food/bakery/all'
    filters = []
    while url not in filters:
        print(url)
        r = requests.get(url,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
        soup = BeautifulSoup(r.text ,"lxml")
        url = soup.findAll('a', {'class': 'pagination--button prev-next'})
        if url in filters:
            filters.append(url)
            print(filters)
            print('scaner API got The all pagination Links for The URL')
            return filters
        filters.append(url)
        for x in url:
            if x:
                url = 'https://eshop.tesco.com.my' + x.get('href')
            else:
                break

get_pagination('https://eshop.tesco.com.my/groceries/en-GB/shop/fresh-food/bakery/all')
