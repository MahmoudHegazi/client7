#!/usr/bin/env python3
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine


Base = declarative_base()



class BakeryLinks(Base):
    __tablename__ = 'bakery_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
        }

class Bakery(Base):
    __tablename__ = 'bakery'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
        }


engine = create_engine('sqlite:///api_scaner.db')
Base.metadata.create_all(engine)
