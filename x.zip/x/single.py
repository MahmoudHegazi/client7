#!/usr/bin/python
from bs4 import BeautifulSoup
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
#from database_setup import Base, User, Element, ElementsMeta, Page, Vote
from flask import session as login_session
import string
import excel
# IMPORTS FOR THIS STEP
import httplib2
import json
from flask import make_response
import requests
import pandas as pd
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
# IMPORTS FOR THIS STEP
import pprint
import httplib2
import json
import sqlite3
from flask import make_response
import requests


app = Flask(__name__)

APPLICATION_NAME = "skaner"

# Connect to Database and create database session
#engine = create_engine('sqlite:///skanner.db')
#Base.metadata.bind = engine

#DBSession = sessionmaker(bind=engine)
#session = DBSession()



# You need install :
# pip install PyPDF2 - > Read and parse your content pdf
# pip install requests - > request for get the pdf
# pip install BeautifulSoup - > for parse the html and find all url hrf with ".pdf" final
from PyPDF2 import PdfFileReader
import requests
import io
from bs4 import BeautifulSoup
import requests
from collections import Counter
import base64

# this function accept one paramter which is list of prudcts links
def get_proudct_data(prudcts_links):
    projectData = []
    # start from Carbs and end with Protein

    for link in prudcts_links:
        url_part1 = link
        #url_part1 = 'https://eshop.tesco.com.my/groceries/en-GB/products/7000010766'
        try:
            response = requests.get(url_part1,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
            content = response.content
            soup = BeautifulSoup(response.content, 'html.parser')
            proudct_image = soup.find('img' , class_="product-image").get('src')
            proudct_name = soup.find('h1' , class_="product-details-tile__title").getText()
            proudct_price = soup.find('span' , class_="value").getText()
            proudct = {"image": proudct_image,"name": proudct_name,"price": proudct_price}
            if proudct not in projectData:
                projectData.append(proudct)
            else:
                continue
        except Exception as e:
            print(e.message, e.args)
            print('API Scanner Blocked For A while Do not Worry We Will override that error Wait 5 minutes...')
            time.sleep(300)
            print('Continue from The Last point..')
            try:
                response = requests.get(url_part1,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
                content = response.content
                soup = BeautifulSoup(response.content, 'html.parser')
                proudct_image = soup.find('img' , class_="product-image").get('src')
                proudct_name = soup.find('h1' , class_="product-details-tile__title").getText()
                proudct_price = soup.find('span' , class_="value").getText()
                proudct = {"image": proudct_image,"name": proudct_name,"price": proudct_price}
                if proudct not in projectData:
                    projectData.append(proudct)
                else:
                    continue
            except Exception as e:
                print(e.message, e.args)
                print('Again API Scanner Blocked For A while Do not Worry We Will override that error Wait 5 minutes...')
                print('Do not worry Nothing Can stop this API')
                time.sleep(400)
                print('Continue from The Last point..')
                response = requests.get(url_part1,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
                content = response.content
                soup = BeautifulSoup(response.content, 'html.parser')
                proudct_image = soup.find('img' , class_="product-image").get('src')
                proudct_name = soup.find('h1' , class_="product-details-tile__title").getText()
                proudct_price = soup.find('span' , class_="value").getText()
                proudct = {"image": proudct_image,"name": proudct_name,"price": proudct_price}
                if proudct not in projectData:
                    projectData.append(proudct)
                else:
                    continue


    return str(projectData)



@app.route('/target')
def targeter():
    all_proudcts = get_proudct_data(['https://eshop.tesco.com.my/groceries/en-GB/products/7000010766',
    'https://eshop.tesco.com.my/groceries/en-GB/products/7070822956'])
    return str(all_proudcts)



"""
thisdict =	[{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
},
{
  "brand": "Ford1",
  "model": "Mustang1",
  "year": 19641
}]
for x in thisdict:
  for i in x:
      print(x[i])
"""

if __name__ == '__main__':
    app.secret_key = 'AS&S^1234Aoshsheo152h23h5j7ks9-1---3*-s,#k>s'
    app.debug = True
    app.run(host='0.0.0.0', port=5000, threaded=False)
