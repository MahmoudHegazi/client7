#!/usr/bin/python
from bs4 import BeautifulSoup
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
#from database_setup import Base, User, Element, ElementsMeta, Page, Vote
from flask import session as login_session
import string
import excel
# IMPORTS FOR THIS STEP
import httplib2
import json
from flask import make_response
import requests
import pandas as pd
from tablib import Dataset
import numpy as np
import excel
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
# IMPORTS FOR THIS STEP
import pprint
import httplib2
import json
import sqlite3
from flask import make_response
import requests


app = Flask(__name__)

APPLICATION_NAME = "skaner"

# Connect to Database and create database session
#engine = create_engine('sqlite:///skanner.db')
#Base.metadata.bind = engine

#DBSession = sessionmaker(bind=engine)
#session = DBSession()



# You need install :
# pip install PyPDF2 - > Read and parse your content pdf
# pip install requests - > request for get the pdf
# pip install BeautifulSoup - > for parse the html and find all url hrf with ".pdf" final
from PyPDF2 import PdfFileReader
import requests
import io
from bs4 import BeautifulSoup
import requests
from collections import Counter
import base64




@app.route('/target')
def targeter():
    projectData = []
    # start from Carbs and end with Protein
    thisdict = {'has_number': [], 'has_no_number': [] }
    #response = requests.get("https://eshop.tesco.com.my/groceries/en-GB/shop/fresh-food/bakery/all", headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
    url_part1 = 'https://eshop.tesco.com.my/groceries/en-GB/shop/fresh-food/bakery/all'
    #url_part2 = 'headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"}'
    response = requests.get(url_part1,headers={"User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"})
    content = response.content
    soup = BeautifulSoup(response.content, 'html.parser')
    #nutritional_sections = soup.find('img', class_="product-image")
    #nutritional_sections = soup.find('div' , class_="product-details--content").text
    top_domain = 'https://eshop.tesco.com.my'
    #nutritional_sections = soup.find('a' , class_="product-image-wrapper").get('href')
    proudcts = soup.find_all('a' , class_="product-image-wrapper")
    for proudct in proudcts:
        proudct_link = top_domain + proudct.get('href')
        projectData.append(proudct_link)
    #for proudct in nutritional_sections:
        #projectData.append(proudct)
        #the_h3 = proudct.findChildren("h3" , recursive=False)
        #proudct_link_tag = the_h3[0].findChildren("a" , recursive=False)
        #proudct_link = str(top_domain + proudct_link_tag[0]['href'])
        #projectData.append(proudct_link)
        #print(proudct_link)
        #--------------
        #print([item["data-auto"] for item in soup.find_all() if "product-tile--title" in item.attrs])
        #soup.find(id="logo").get('src')
        #projectData.append(nutritional_sections)
        #with open('new.gif', 'wb') as f: pagination--button prev-next
        #    f.write(base64.b64decode('R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=='))
    return str(projectData)


if __name__ == '__main__':
    app.secret_key = 'AS&S^1234Aoshsheo152h23h5j7ks9-1---3*-s,#k>s'
    app.debug = True
    app.run(host='0.0.0.0', port=5000, threaded=False)
